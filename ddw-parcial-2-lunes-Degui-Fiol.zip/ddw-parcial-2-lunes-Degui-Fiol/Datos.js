/* Martina Degui y Ramiro Fiol */
/* DATOS DE ITEMS DE LA TIENDA */

let shopItemsData = [
    {
        id:"primero",
        name:"Colombia",
        price: 100,
        desc:"Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        img:"images/colombia.jpeg"

    },
    {
        id:"segundo",
        name:"Mexico",
        price: 100,
        desc:"Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        img:"images/mexico.jpg"
    },
    {
        id:"tercero",
        name:"Espana",
        price: 100,
        desc:"Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        img:"images/espa.jpg"
    },
    { 
        id:"cuarto",
        name:"Croacia",
        price: 100,
        desc:"Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        img:"images/croacia.jpg"
    },
    { 
        id:"quinto",
        name:"Argentina",
        price: 100,
        desc:"Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        img:"images/arg.jpg"
    },
    { 
        id:"sexto",
        name:"Francia",
        price: 100,
        desc:"Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        img:"images/francia.jpg"
    },
];